import React, { useState } from 'react';
import { Container, Typography, TextField, Button, Paper, Alert } from '@mui/material';
import db from '../db';
import { seedSampleData } from '../db/sampleData';
import { useTranslation } from 'react-i18next';

function Login({ onLogin }) {
  const { t } = useTranslation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  React.useEffect(() => {
    (async () => {
      const count = await db.users.count();
      if (count === 0) {
        await seedSampleData();
      }
    })();
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    const user = await db.users.where('username').equals(username).first();
    if (user && user.passwordHash === password) {
      onLogin(user);
    } else {
      setError('Invalid username or password');
    }
  }

  return (
    <Container maxWidth="xs" sx={{ mt: 8 }}>
      <Paper sx={{ p: 3 }}>
        <Typography variant="h5" gutterBottom>{t('Login')}</Typography>
        {error && <Alert severity="error">{t(error)}</Alert>}
        <form onSubmit={handleSubmit}>
          <TextField label={t('Username')} value={username} onChange={e => setUsername(e.target.value)} fullWidth sx={{ mb: 2 }} />
          <TextField label={t('Password')} type="password" value={password} onChange={e => setPassword(e.target.value)} fullWidth sx={{ mb: 2 }} />
          <Button type="submit" variant="contained" fullWidth>{t('Login')}</Button>
        </form>
      </Paper>
    </Container>
  );
}

export default Login;
